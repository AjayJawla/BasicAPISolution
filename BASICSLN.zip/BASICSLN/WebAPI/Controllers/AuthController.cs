﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthServiceIdentity _identity;
        private readonly IAuthServiceLocal _local;
        private readonly Response _response;
        public AuthController(IAuthServiceIdentity identity, IAuthServiceLocal local)
        {
            _identity = identity;
            _response = new();
            _local = local;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegistrationRequestDTO registrationRequestDTO)
        {
            var response = await _identity.Register(registrationRequestDTO);
            return Ok(response);
        }

        /// <summary>
        /// Created By : Ajay
        /// Description : This funtion is used to login and it return you back userinformation with JWT token.
        /// </summary>
        /// <param name="requestDTO"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("login")]
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Response))]
        [ProducesResponseType(StatusCodes.Status500InternalServerError, Type = typeof(Response))]      
        public async Task<IActionResult> Login([FromBody] LoginRequestDTO requestDTO)
        {
            try
            {
                //Below function is used when you use default microsoft identity in database. Use this for better security
                //var response = await _identity.Login(requestDTO);

                //Below function is used when you have already database and you have your own tables realted to user.
                var response = await _local.Login(requestDTO);


                return StatusCode(StatusCodes.Status200OK, response);
            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Message = ex.Message;
                return StatusCode(StatusCodes.Status500InternalServerError, _response);
            }
           
            
           
        }

        [HttpPost("assignRole")]
        public async Task<IActionResult> AssignRole([FromBody] RegistrationRequestDTO requestDTO)
        {
            var response = await _identity.AssignRole(requestDTO.Email,requestDTO.Role.ToUpper().ToString());
            return Ok(response);
        }
    }
}

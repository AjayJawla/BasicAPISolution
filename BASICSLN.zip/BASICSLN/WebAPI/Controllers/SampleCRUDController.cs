﻿using BusinessLogic.Employee;
using DTO.Employee;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Principal;

namespace WebAPI.Controllers
{
    /// <summary>
    /// Created By : Ajay
    /// Description : All funtion is accessible after you pass bearer token. You can pass token after click on lock symbol.
    /// </summary>
    [Route("api/sample")]
    [ApiController]
    [Authorize]
    public class SampleCRUDController : ControllerBase
    {

        private readonly Response _response;
        private readonly IEmployeeBL _employeeBL;
        public SampleCRUDController(IEmployeeBL employee)
        {
            _employeeBL = employee;
            _response = new();
        }


        /// <summary>
        /// Created By : Ajay         
        /// Description : This funtion is accessible after you pass bearer token. You can pass token after click on lock symbol.
        /// </summary>
        /// <returns></returns>
        [HttpGet("getsamplestatic")]
        public async Task<IActionResult> Get()
        {
            _response.Data = "Simple Example";
            _response.Message = "Test";
            return Ok(_response);
        }

        /// <summary>
        /// Created By : Ajay
        /// Description : This funtion is accessible after you pass bearer token. You can pass token after click on lock symbol.
        /// </summary>
        /// <param name="createEmployeeDto"></param>
        /// <returns></returns>
        [HttpPost("addemployee")]
        public async Task<IActionResult> AddEmployee([FromBody] CreateEmployeeDto createEmployeeDto)
        {
            var result=await _employeeBL.AddEmployee(createEmployeeDto);
            return Ok(_response);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.LocalAuthService
{
    public class AuthServiceLocal : IAuthServiceLocal
    {
        private readonly IEmployeeBL _employeeBL;
        public readonly IJWTGenerator _jWTGenerator;
        public AuthServiceLocal(IEmployeeBL employeeBL, IJWTGenerator jWTGenerator)
        {
            _employeeBL = employeeBL;
            _jWTGenerator = jWTGenerator;
        }
        public async Task<Response> Login(LoginRequestDTO loginRequestDTO)
        {
            Response response = new();
            try
            {
                var user = await _employeeBL.GetEmployeeByEmail(loginRequestDTO.UserName);
                if(user!=null && user.Data!=null)
                {
                    var responseData = user.Data;
                    if(responseData is DAL.Models.Employee)
                    {
                        var employee=(DAL.Models.Employee)responseData;
                        if(employee.EmployeePassword==loginRequestDTO.Password)
                        {
                            var token = _jWTGenerator.GenerateTokenFromLocal(employee);
                            UserDTO userDTO = new()
                            {
                                Email = employee.EmployeeEmail,
                                ID = employee.Id.ToString(),
                                Name = employee.EmployeeName,
                                PhoneNumber = employee.EmployeePhoneNumber
                            };
                            LoginResponseDTO loginResponse = new()
                            {
                                User = userDTO,
                                Token = token
                            };
                            response.Data = loginResponse;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return response;            
        }
    }
}

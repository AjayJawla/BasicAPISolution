﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Token
{
    public interface IJWTGenerator
    {
        string GenerateToken(ApplicationUser user);
        string GenerateToken(ApplicationUser user,IEnumerable<string> roles);

        string GenerateTokenFromLocal(DAL.Models.Employee user);
    }
}

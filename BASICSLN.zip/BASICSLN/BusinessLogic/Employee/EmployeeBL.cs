﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Employee
{
    public class EmployeeBL:IEmployeeBL
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IMapper _mapper;
        public EmployeeBL(IEmployeeRepository employeeRepository,IMapper mapper)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }

        public async Task<Response> AddEmployee(CreateEmployeeDto employeeDto)
        {
            Response response = new();
            try
            {
                var employee = _mapper.Map<CreateEmployeeDto, DAL.Models.Employee>(employeeDto);
                var result = await _employeeRepository.InsertAsync(employee);
                response.Data = result;                
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<Response> GetEmployeeByEmail(string Email)
        {
            Response response = new();
            try
            {               
                var result = await _employeeRepository.GetUsingFilter(x=>x.EmployeeEmail==Email);
                response.Data = result;
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return response;
        }
    }
}

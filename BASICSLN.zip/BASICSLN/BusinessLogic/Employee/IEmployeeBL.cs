﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Employee
{
    public interface IEmployeeBL
    {
        Task<Response> AddEmployee(CreateEmployeeDto employeeDto);
        Task<Response> GetEmployeeByEmail(string Email);
    }
}

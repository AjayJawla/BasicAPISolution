﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonRepo.EmployeeRepo
{
    public class EmployeeRepository:CRUDGenericRepo<Employee>,IEmployeeRepository
    {
        #region :: Dependency Injection ::
        private readonly ApplicationDbContext _dbContext;
        public EmployeeRepository(ApplicationDbContext dbContext):base(dbContext)
        {
                _dbContext = dbContext;
        }
        #endregion
    }
}

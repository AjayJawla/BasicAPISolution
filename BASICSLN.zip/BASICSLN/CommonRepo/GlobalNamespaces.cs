﻿global using DAL;
global using DAL.Models;
global using DTO;
global using GenricRepo;

﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
namespace GenricRepo
{
    public interface IWebService
    {
        Task<T> GetAsync<T>(string url, string token) where T : class;       
        Task<T> GetAsync<T>(string url, int Id, string token) where T : class;       
        Task<T> GetAsync<T>(string url, string Id, string token) where T : class;
        Task<IEnumerable<T>> GetAllAsync<T>(string url, string token) where T : class;
        Task<bool> CreateAsync<T>(string url, T objToCreate, string token) where T : class;
        Task<Response> CreateAsyncReturnType<T>(string url, T objToCreate, string token) where T : class;
        Task<bool> UpdateAsync<T>(string url, T objToUpdate, string token) where T : class;
        Task<Response> UpdateAsyncReturnType<T>(string url, T objToUpdate, string token) where T : class;
        Task<bool> DeleteAsync(string url, int Id, string token);
        Task<Response> DeleteAsyncReturnType(string url, int Id, string token);
        Task<Response> DeleteAsyncReturnType(string url, string token);
    }
}

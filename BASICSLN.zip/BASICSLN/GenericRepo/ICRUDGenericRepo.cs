﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace GenricRepo
{
    public interface ICRUDGenericRepo<T> where T: class
    {
        Task<bool> UpdateAsync(T objToUpdate);
        Task<bool> Save();
        Task<bool> InsertAsync(T objToInsert);
        Task<bool> InsertAllAsync(List<T> objToInsert);
        Task<T> GetOneAsync(int Id);
        Task<T> GetOneAsync(string Id);
        Task<IEnumerable<T>> GetAllAsync();
        Task<bool> DeleteAsync(T objToDelete);
        Task<bool> DeleteAllAsync(List<T> objToDelete);
        Task<T> GetUsingFilter(Expression<Func<T,bool>> expression);
    }
}

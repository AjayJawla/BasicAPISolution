﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Common;
using Newtonsoft.Json;
namespace GenricRepo
{
    public class WebService:IWebService
    {
        #region :: DEPENDENCY INJECTION ::
        private readonly IHttpClientFactory _clientFactory;
        public WebService(IHttpClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }
        #endregion

        #region CreateAsync
        public async Task<bool> CreateAsync<T>(string url, T objToCreate, string token) where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Post, url);

            //check objToCreate not equl to null
            if (objToCreate != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(objToCreate), Encoding.UTF8, "application/json");
            }
            else
            {
                return false;
            }

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.Created)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<Response> CreateAsyncReturnType<T>(string url, T objToCreate, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Post, url);

            //check objToCreate not equl to null
            if (objToCreate != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(objToCreate), Encoding.UTF8, "application/json");
            }
            else
            {
                return new Response() { Data = null, IsSuccess=false, Message = "Oject you pass is null!" };
            }

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            var jsonstring = await responseMessage.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<Response>(jsonstring);

        }

        #endregion

        /// <summary>
        /// DeleteAsync
        /// </summary>
        /// <param name="url"></param>
        /// <param name="Id"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        #region DeleteAsync
        public async Task<bool> DeleteAsync(string url, int Id, string token)
        {
            //create a request
            var Ids = "?Id=" + Id;
            var request = new HttpRequestMessage(HttpMethod.Post, url + Ids);
            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion

        /// <summary>
        /// DeleteAsyncReturnType
        /// </summary>
        /// <param name="url"></param>
        /// <param name="Id"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        #region DeleteAsyncReturnType
        public async Task<Response> DeleteAsyncReturnType(string url, int Id, string token)
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Delete, url + Id);

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            var jsonstring = await responseMessage.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<Response>(jsonstring);
        }
        #endregion

        /// <summary>
        /// DeleteAsyncReturnType
        /// </summary>
        /// <param name="url"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        #region DeleteAsyncReturnType
        public async Task<Response> DeleteAsyncReturnType(string url, string token = "")
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Post, url);

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            var jsonstring = await responseMessage.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<Response>(jsonstring);
        }

        #endregion

        /// <summary>
        /// GetAllAsync
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="url"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        /// 
        #region GetAllAsync
        public async Task<IEnumerable<T>> GetAllAsync<T>(string url, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Get, url);

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonstring = await responseMessage.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<IEnumerable<T>>(jsonstring);
            }
            return null;
        }
        #endregion

        #region :: GetSingle ::
        public async Task<T> GetAsync<T>(string url, int Id, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Get, url + Id);

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonstring = await responseMessage.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(jsonstring);
            }
            return null;
        }

        

        public async Task<T> GetAsync<T>(string url, string Id, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Get, url + Id);

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonstring = await responseMessage.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(jsonstring);
            }
            return null;
        }



        public async Task<T> GetAsync<T>(string url, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Get, url);

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var jsonstring = await responseMessage.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T>(jsonstring);
            }
            return null;
        }
        #endregion

        #region :: Update ::
        public async Task<bool> UpdateAsync<T>(string url, T objToUpdate, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Patch, url);

            //check objToCreate not equl to null
            if (objToUpdate != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(objToUpdate), Encoding.UTF8, "application/json");
            }
            else
            {
                return false;
            }

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<Response> UpdateAsyncReturnType<T>(string url, T objToUpdate, string token = "") where T : class
        {
            //create a request
            var request = new HttpRequestMessage(HttpMethod.Patch, url);

            //check objToCreate not equl to null
            if (objToUpdate != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(objToUpdate), Encoding.UTF8, "application/json");
            }
            else
            {
                return new Response() { Data = null, IsSuccess=false, Message = "Oject you pass is null!" };
            }

            var client = _clientFactory.CreateClient();
            if (!String.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            HttpResponseMessage responseMessage = await client.SendAsync(request);
            var jsonstring = await responseMessage.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<Response>(jsonstring);
        }
        #endregion

    }
}

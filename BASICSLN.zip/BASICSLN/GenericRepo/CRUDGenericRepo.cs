﻿using DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace GenricRepo
{
    public class CRUDGenericRepo<T>:ICRUDGenericRepo<T> where T : class
    {
        #region :: DependencyInjection ::
        private readonly ApplicationDbContext _context;
        private DbSet<T> entity;
        public CRUDGenericRepo(ApplicationDbContext context)
        {
            _context = context;
            entity = context.Set<T>();
        }
        #endregion

        #region :: Delete ::
        public async Task<bool> DeleteAsync(T objToDelete)
        {
            entity.Remove(objToDelete);
            return await Save();
        }
        #endregion

        #region :: Delete All ::
        public async Task<bool> DeleteAllAsync(List<T> objToDelete)
        {
            entity.RemoveRange(objToDelete);
            return await Save();
        }
        #endregion

        #region :: Save ::
        public async Task<bool> Save()
        {
            return await _context.SaveChangesAsync() > 0 ? true : false;
        }
        #endregion

        #region :: Update ::
        public async Task<bool> UpdateAsync(T objToUpdate)
        {
            entity.Update(objToUpdate);
            return await Save();
        }
        #endregion

        #region :: Insert ::
        public async Task<bool> InsertAsync(T objToUpdate)
        {
            await entity.AddAsync(objToUpdate);
            return await Save();
        }
        #endregion

        #region :: InsertAll ::
        public async Task<bool> InsertAllAsync(List<T> objToInsert)
        {
            await entity.AddRangeAsync(objToInsert);
            return await Save();
        }
        #endregion

        #region :: GetOneRecord ::
        public async Task<T> GetOneAsync(int Id)
        {
            return await entity.FindAsync(Id);
        }

        public async Task<T> GetOneAsync(string Id)
        {
            return await entity.FindAsync(Id);
        }
        #endregion

        #region :: GetAllRecord ::
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await entity.ToListAsync();
        }
        #endregion

        #region :: GetOneUsingFilter ::
        public async Task<T> GetUsingFilter(Expression<Func<T, bool>> expression)
        {
            return await _context.Set<T>().FirstOrDefaultAsync(expression);
        }
        #endregion
    }
}

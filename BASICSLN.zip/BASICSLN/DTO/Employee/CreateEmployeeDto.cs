﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO.Employee
{
    public class CreateEmployeeDto
    {
        public string? EmployeeName { get; set; }
        public string? EmployeeEmail { get; set; }
        public string? EmployeePassword { get; set; }
        public string? EmployeePhoneNumber { get; set; }
    }
}

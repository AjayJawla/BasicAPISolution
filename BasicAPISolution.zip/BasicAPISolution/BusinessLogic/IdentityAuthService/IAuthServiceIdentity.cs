﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.IdentityAuthService
{
    public interface IAuthServiceIdentity
    {
        Task<Response> Register(RegistrationRequestDTO registrationRequestDTO);
        Task<Response> Login(LoginRequestDTO loginRequestDTO);
        Task<Response> AssignRole(string email,string roleName);

    }
}

﻿
using DTO.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.IdentityAuthService
{
    public class AuthServiceIdentity : IAuthServiceIdentity
    {
        public readonly ApplicationDbContext _dbContext;
        public readonly UserManager<ApplicationUser> _userManager;
        public readonly RoleManager<IdentityRole> _roleManager;
        public readonly IJWTGenerator _jWTGenerator;
        public AuthServiceIdentity(ApplicationDbContext dbContext,UserManager<ApplicationUser> userManager,RoleManager<IdentityRole> roleManager,IJWTGenerator jWTGenerator)
        {
            _dbContext = dbContext;
            _userManager = userManager;
            _roleManager = roleManager;
            _jWTGenerator = jWTGenerator;

        }

        public async Task<Response> AssignRole(string email, string roleName)
        {
            Response response = new();
            try
            {
                var user = _dbContext.ApplicationUser.FirstOrDefault(x => x.Email.ToLower() == email.ToLower());
                if (user != null)
                {
                    if(!_roleManager.RoleExistsAsync(roleName).GetAwaiter().GetResult())
                    {
                        await _roleManager.CreateAsync(new IdentityRole(roleName));
                    }
                    await _userManager.AddToRoleAsync(user,roleName);
                    
                    response.Message = "Role is assigned!";
                }
                else
                {
                    response.Data = null;
                    response.IsSuccess = false;
                    response.Message = "Role not assigned!";
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<Response> Login(LoginRequestDTO loginRequestDTO)
        {
            Response response = new();
            try
            {
                var user = _dbContext.ApplicationUser.FirstOrDefault(x=>x.UserName.ToLower()==loginRequestDTO.UserName.ToLower());
                bool isValid = await _userManager.CheckPasswordAsync(user,loginRequestDTO.Password);
                if (user == null || isValid==false)
                {
                    response.Data = null;
                    response.IsSuccess = false;
                    response.Message = "User/Password is incorrect!";
                }
                else
                {
                    //use this function if you don't want role in claim
                    //var token = _jWTGenerator.GenerateToken(user);

                    //
                    var roles = await _userManager.GetRolesAsync(user);
                    var token = _jWTGenerator.GenerateToken(user,roles);

                    UserDTO userDTO = new()
                    {
                        Email = user.Email,
                        ID = user.Id,
                        Name = user.Email,
                        PhoneNumber = user.PhoneNumber
                    };
                    LoginResponseDTO loginResponse = new()
                    {
                        User = userDTO,
                        Token= token
                    };
                    response.Data = loginResponse;

                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            return response;
        }

        public async Task<Response> Register(RegistrationRequestDTO registrationRequestDTO)
        {
            Response response = new();
            ApplicationUser user = new()
            {
                UserName = registrationRequestDTO.Email,
                Email = registrationRequestDTO.Email,
                NormalizedEmail = registrationRequestDTO.Email.ToUpper(),
                PhoneNumber=registrationRequestDTO.PhoneNumber,                
            };
            try
            {
                var result = await _userManager.CreateAsync(user, registrationRequestDTO.Password);
                if(result.Succeeded)
                {
                    var userToReturn = _dbContext.ApplicationUser.First(x=>x.UserName==registrationRequestDTO.Email);

                    UserDTO userDTO = new()
                    {
                        Email = userToReturn.Email,
                        ID = userToReturn.Id,
                        Name = userToReturn.Email,
                        PhoneNumber = userToReturn.PhoneNumber
                    };

                    response.Data = userDTO;
                }
                else
                {
                    response.Data = null;
                    response.IsSuccess = false;
                    response.Message = result.Errors.First().Description;
                }
            }
            catch (Exception ex)
            {
                response.Data = null;
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthServiceIdentity _identity;
        private readonly Response _response;
        public AuthController(IAuthServiceIdentity identity)
        {
            _identity = identity;
            _response = new();
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegistrationRequestDTO registrationRequestDTO)
        {
            var response = await _identity.Register(registrationRequestDTO);
            return Ok(response);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDTO requestDTO)
        {
            var response = await _identity.Login(requestDTO);
            return Ok(response);
        }

        [HttpPost("assignRole")]
        public async Task<IActionResult> AssignRole([FromBody] RegistrationRequestDTO requestDTO)
        {
            var response = await _identity.AssignRole(requestDTO.Email,requestDTO.Role.ToUpper().ToString());
            return Ok(response);
        }
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Principal;

namespace WebAPI.Controllers
{
    [Route("api/sample")]
    [ApiController]
    [Authorize]
    public class SampleCRUDController : ControllerBase
    {

        private readonly Response _response;
        public SampleCRUDController()
        {           
            _response = new();
        }

        [HttpGet("getsamplestatic")]
        public async Task<IActionResult> Get()
        {
            _response.Data = "Simple Example";
            _response.Message = "Test";
            return Ok(_response);
        }
    }
}
